from django.apps import AppConfig


class GasUtilitiesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gas_utilities'
