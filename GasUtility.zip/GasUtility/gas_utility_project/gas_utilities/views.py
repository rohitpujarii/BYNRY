from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
# Create your views here.
# views.py
from django.shortcuts import render, redirect
from .models import ServiceRequest
from .forms import ServiceRequestForm

@login_required
def submit_request(request):
    if request.method == 'POST':
        form = ServiceRequestForm(request.POST, request.FILES)
        if form.is_valid():
            # Associate the service request with the logged-in customer
            service_request = form.save(commit=False)
            service_request.customer = request.user.customer
            service_request.save()
            return redirect('request_tracking')
    else:
        form = ServiceRequestForm()
    return render(request, 'submit_request.html', {'form': form})
@login_required
def request_tracking(request):
    # Ensure that the user has an associated customer instance
    if hasattr(request.user, 'customer'):
        customer = request.user.customer
        # Retrieve and display service request status for the logged-in customer
        requests = ServiceRequest.objects.filter(customer=customer)
        return render(request, 'request_tracking.html', {'requests': requests})
    else:
        
        # Handle the case where the user doesn't have a customer instance
        # Redirect or display an appropriate message
        return HttpResponse("You do not have access to this feature.")
